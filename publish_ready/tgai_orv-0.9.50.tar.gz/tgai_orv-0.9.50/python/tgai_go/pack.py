# -*- coding: utf-8 -*-
"""`.TG` 打包器：按 tgai_format.h 写 header + tokenizer + 权重表 + 权重数据 + chat meta。

字段来源（已核对源码）：
  TGHeader        embedded/TGAI_GO/src/tgai_format.h:166  (128B, pack(1))
  TGWeightEntry   同文件 (52B)：name_hash/offset/length/dtype/ndim/shape[4]/scale
  tokenizer 段    同文件注释：u32 vocab_size, u32 n_merges, merges(u16,u16)*n,
                  tokens(u8 len + bytes)*vocab, u8[16] special ids
  chat meta 段    src/tgai_chat_meta.c：12B 头 [magic,version,count] + [u32 type,u32 len,data]*
                  由 header.extension_off 定位（u32；>=2^31 表示相对文件尾的负数偏移）
  name_hash       src/tgai_engine.c fnv1a_64（seed 0xcbf29ce484222325, prime 0x100000001b3）

用法:
    from tgai_pack import TGWriter
    w = TGWriter(n_layers=1, d_model=256, n_heads=8, d_ff=1024, vocab=78,
                 max_seq=256, n_experts=1, n_activated=1, rope_theta=10000,
                 pad=0, bos=1, eos=2, unk=3)
    w.add_weights({"token_embedding.weight": emb, ...})
    w.set_tokenizer(vocab_list, merges=[(a,b), ...])
    w.set_chat_meta({5: b"...", 4: b"..."})
    w.write("model.tg")
"""
import struct

import numpy as np

TG_MAGIC = 0x49414754
TG_VERSION = 1
TG_ARCH_TGAI_MOE = 0
DT_FP32, DT_FP16, DT_INT8, DT_INT32 = 0, 1, 2, 3
#: 量化 / 半精度扩展（与产线一致）：
#: 4=Q8_0、5=Q4_0 是 `.TG` 里已有的量化容器码；6=BF16 是 V2.7 用的实际存储类型
#:   （实测 D:\TGAI\models\V2.7\TGAI_NB_V2.7.tg 头 weight_dtype=6、869/982 张量是 dtype 6）。
#: bf16 与 fp32 的换算只是左移/右移 16 位，无损。
DT_Q8_0, DT_Q4_0, DT_BF16 = 4, 5, 6
TG_CHAT_META_MAGIC = 0x46434754
TG_CHAT_META_VERSION = 1


def fnv1a64(name: str) -> int:
    h = 0xCBF29CE484222325
    for b in name.encode("utf-8"):
        h ^= b
        h = (h * 0x100000001B3) & 0xFFFFFFFFFFFFFFFF
    return h


class TGWriter:
    def __init__(self, n_layers, d_model, n_heads, d_ff, vocab, max_seq,
                 n_experts=8, n_activated=2, rope_theta=10000,
                 pad=0, bos=1, eos=2, unk=3, n_kv_heads=0, arch=TG_ARCH_TGAI_MOE,
                 weight_dtype=DT_FP16):
        self.cfg = dict(n_layers=n_layers, d_model=d_model, n_heads=n_heads, d_ff=d_ff,
                        vocab=vocab, max_seq=max_seq, n_experts=n_experts,
                        n_activated=n_activated, rope_theta=rope_theta,
                        pad=pad, bos=bos, eos=eos, unk=unk, n_kv_heads=n_kv_heads,
                        arch=arch, weight_dtype=weight_dtype)
        self.weights = []          # [(name, np.ndarray, dtype)]
        self.vocab_tokens = []
        self.merges = []
        self.specials = [0] * 16
        self.chat_meta = {}        # {type: bytes}
        self.dtype_overrides = {}  # 逐张量 dtype 覆盖（{name: TGDtype}）

    # ---------- 内容 ----------
    def add_weight(self, name, arr):
        a = np.ascontiguousarray(arr)
        self.weights.append((name, a))

    def add_weights(self, mapping):
        for k, v in mapping.items():
            self.add_weight(k, v.detach().float().cpu().numpy() if hasattr(v, "detach") else v)

    def set_tokenizer(self, tokens, merges=None, special_ids=None):
        self.vocab_tokens = list(tokens)
        self.merges = list(merges or [])
        if special_ids:
            for i, v in enumerate(special_ids[:16]):
                self.specials[i] = int(v)

    # chat meta 的 type 常量（与 src/tgai_chat_meta.h 一致）
    CM_CHAT_TEMPLATE, CM_STOP_STRINGS, CM_TURN_MARKERS = 1, 2, 3
    CM_SPECIAL_TOKENS, CM_GEN_DEFAULTS, CM_SYSTEM_PROMPT = 4, 5, 6
    CM_RENDER_MODE, CM_TEMPLATE_TURN = 7, 8

    def set_chat_meta(self, entries: dict):
        """结构化写入 chat meta，自动按引擎格式编码：

            {5: {"temperature": "0.7"}}        # GEN_DEFAULTS  → k=v 用 \\x00 分隔
            {4: ["<pad>", "<bos>"]}            # SPECIAL_TOKENS → 列表用 \\x00 分隔
            {1: "模板字符串"}                    # 其余 → 纯 UTF-8 字符串
            {9: b"raw bytes"}                   # 已是 bytes 则原样写
        """
        out = {}
        for t, v in entries.items():
            if isinstance(v, bytes):
                out[int(t)] = v
            elif isinstance(v, dict):
                out[int(t)] = b"\x00".join(
                    (str(k) + "=" + str(val)).encode("utf-8") for k, val in v.items())
            elif isinstance(v, (list, tuple)):
                out[int(t)] = b"\x00".join(str(x).encode("utf-8") for x in v)
            else:
                out[int(t)] = str(v).encode("utf-8")
        self.chat_meta = out

    # ---------- 序列化 ----------
    def _tokenizer_bytes(self):
        out = bytearray()
        out += struct.pack("<II", len(self.vocab_tokens), len(self.merges))
        for a, b in self.merges:
            out += struct.pack("<HH", a, b)
        for tok in self.vocab_tokens:
            bs = tok.encode("utf-8")
            if len(bs) > 255:
                raise ValueError("token 过长: %r" % tok)
            out += struct.pack("<B", len(bs)) + bs
        sp = list(self.specials[:16])
        sp += [0] * (16 - len(sp))
        out += bytes(sp)
        return bytes(out)

    def _chat_meta_bytes(self):
        if not self.chat_meta:
            return b""
        out = bytearray()
        out += struct.pack("<III", TG_CHAT_META_MAGIC, TG_CHAT_META_VERSION, len(self.chat_meta))
        for t, data in self.chat_meta.items():
            out += struct.pack("<II", int(t), len(data)) + data
        return bytes(out)

    def _header(self, tok_off, tok_len, wt_off, wt_cnt, wd_off, wd_len,
                has_meta=False, version=None):
        """打包 128B 头。>2 GB 时 extension_off 用**负偏移**（相对文件尾），与产线一致：
        产线 V2.7 实测为 4294966890 == int32(-406) == EOF-406。"""
        dtype = self.cfg["weight_dtype"]
        ext = 0
        if has_meta:
            meta_off = wd_off + wd_len
            ext = meta_off & 0xFFFFFFFF if meta_off < 0x80000000 else (meta_off - (1 << 32)) & 0xFFFFFFFF
        hdr = struct.pack(
            "<16I6Q4I",
            TG_MAGIC, (TG_VERSION if version is None else int(version)), dtype,
            self.cfg["n_layers"], self.cfg["d_model"], self.cfg["n_heads"],
            self.cfg["d_ff"], self.cfg["vocab"], self.cfg["max_seq"],
            self.cfg["n_experts"], self.cfg["n_activated"], self.cfg["rope_theta"],
            self.cfg["pad"], self.cfg["bos"], self.cfg["eos"], self.cfg["unk"],
            tok_off, tok_len, wt_off, wt_cnt, wd_off, wd_len,
            self.cfg["arch"], self.cfg["n_kv_heads"], 0, ext)
        assert len(hdr) == 128, "header 长度 %d != 128" % len(hdr)
        return hdr

    def write(self, path):
        tok = self._tokenizer_bytes()
        meta = self._chat_meta_bytes()

        # 权重：按目标 dtype 转换
        blob = bytearray()
        entries = []
        dtype = self.cfg["weight_dtype"]
        for name, arr in self.weights:
            flat = arr.reshape(-1)
            if dtype == DT_FP16:
                data = flat.astype(np.float16).tobytes()
                dt = DT_FP16
            elif dtype == DT_BF16:
                # bf16 = fp32 的高 16 位（截断，与产线 V2.7 的 bf16 .TG 一致）
                u = np.ascontiguousarray(flat, dtype=np.float32).view(np.uint32).astype(np.uint64)
                u = (u + 0x7FFF + ((u >> 16) & 1)) >> 16      # 就近舍入，与产线一致
                data = u.astype(np.uint16).tobytes()
                dt = DT_BF16
            else:
                data = flat.astype(np.float32).tobytes()
                dt = DT_FP32
            off = len(blob)
            blob += data
            shape = list(arr.shape)[:4] + [1] * max(0, 4 - len(arr.shape))
            entries.append((fnv1a64(name), off, len(data), dt, min(len(arr.shape), 4),
                            shape, 0))

        tok_off = 128
        wt_off = tok_off + len(tok)
        wd_off = wt_off + 52 * len(entries)
        meta_off = wd_off + len(blob)
        hdr = self._header(tok_off, len(tok), wt_off, len(entries), wd_off, len(blob), bool(meta))

        with open(path, "wb") as f:
            f.write(hdr)
            f.write(tok)
            for (nh, off, ln, dt, nd, shape, sc) in entries:
                f.write(struct.pack("<QQQII", nh, off, ln, dt, nd))
                f.write(struct.pack("<IIII", *shape))
                f.write(struct.pack("<I", sc))
            f.write(blob)
            if meta:
                f.write(meta)
        return dict(path=path, size=128 + len(tok) + 52 * len(entries) + len(blob) + len(meta),
                    n_weights=len(entries), tokenizer_len=len(tok), has_meta=bool(meta))
    def dtype_for(self, name):
        """逐张量 dtype —— 实测产线 `{bf16: 869, fp32: 113}`：

        113 = 28×2 个 `attn.rope.cos/sin`（56）+ 28×2 个 `ln1/ln2`（56）+ `final_norm`（1）。
        即 **rope 表与所有 norm 权重用 fp32**，其余 bf16。写错会让 WGT 与产线差 116,736 字节（实测）。
        """
        if name.endswith(("rope.cos", "rope.sin")):
            return DT_FP32
        if name.endswith(("ln1.weight", "ln2.weight")) or name == "final_norm.weight":
            return DT_FP32
        return self.dtype_overrides.get(name, self.cfg["weight_dtype"])

    def write_stream(self, path, items, version=None, tok_blob=None):
        """**流式**写 .TG：items 是 (name, ndarray) 的迭代器，写一个释放一个。

        为什么需要：3B 权重 fp32 约 12 GB，write() 会把全部数据攒在 lob 里
        （实测会把 32 GB 机器拖死）。这里改成：权重先流到临时文件，记录偏移，
        最后把「头 + 分词表 + 权重表 + 数据 + chat meta」拼成最终文件。

        峰值内存 = 单张量；额外磁盘 = 一倍文件大小。
        """
        import os, tempfile
        tok = tok_blob if tok_blob is not None else self._tokenizer_bytes()
        meta = self._chat_meta_bytes()
        entries = []
        fd, tmp = tempfile.mkstemp(suffix=".wgt", dir=os.path.dirname(os.path.abspath(path)))
        os.close(fd)
        off = 0
        try:
            with open(tmp, "wb") as f:
                for name, arr in items:
                    dtype = self.dtype_for(name)
                    flat = np.ascontiguousarray(arr).reshape(-1)
                    if dtype == DT_FP16:
                        data = flat.astype(np.float16).tobytes(); dt = DT_FP16
                    elif dtype == DT_BF16:
                        u = np.ascontiguousarray(flat, dtype=np.float32).view(np.uint32).astype(np.uint64)
                        u = (u + 0x7FFF + ((u >> 16) & 1)) >> 16
                        data = u.astype(np.uint16).tobytes(); dt = DT_BF16
                    else:
                        data = flat.astype(np.float32).tobytes(); dt = DT_FP32
                    f.write(data)
                    shape = list(np.shape(arr))[:4] + [1] * max(0, 4 - len(np.shape(arr)))
                    entries.append((fnv1a64(name), off, len(data), dt, min(len(np.shape(arr)), 4), shape, 0))
                    off += len(data)
                    del data
            tok_off = 128
            wt_off = tok_off + len(tok)
            wd_off = wt_off + 52 * len(entries)
            meta_off = wd_off + off
            table = bytearray()
            for (h, o, ln, dt, nd, shape, sc) in entries:
                table += struct.pack("<QQQII4II", h, o, ln, dt, nd, *shape, sc)
            hdr = self._header(tok_off, len(tok), wt_off, len(entries), wd_off, off,
                               bool(meta), version=version)
            with open(path, "wb") as out:
                out.write(hdr); out.write(tok); out.write(bytes(table))
                with open(tmp, "rb") as src:
                    while True:
                        b = src.read(1 << 22)
                        if not b: break
                        out.write(b)
                if meta: out.write(meta)
        finally:
            try: os.remove(tmp)
            except Exception: pass
        return path
